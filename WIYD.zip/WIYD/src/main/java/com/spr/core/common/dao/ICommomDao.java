package com.spr.core.common.dao;

import org.apache.ibatis.session.SqlSession;

public interface ICommomDao {

	public SqlSession getSqlSession();
}
