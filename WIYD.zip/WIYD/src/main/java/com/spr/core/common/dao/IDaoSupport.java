package com.spr.core.common.dao;

public interface IDaoSupport {

}
