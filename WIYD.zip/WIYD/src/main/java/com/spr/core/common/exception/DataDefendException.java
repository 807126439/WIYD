package com.spr.core.common.exception;

public class DataDefendException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2725574027368788136L;

	public DataDefendException(String message) {
		super(message);
		
	}
	
	

}
